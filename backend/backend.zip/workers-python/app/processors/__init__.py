"""Processadores de dados"""
