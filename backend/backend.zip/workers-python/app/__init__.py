"""Python Workers para processamento de telemetria do Kafka"""

__version__ = "1.2.8.1"
